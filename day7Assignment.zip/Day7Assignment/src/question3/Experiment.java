package question3;

public class Experiment extends  Demo {
	
  
	
	public Experiment() {
		super();
		
		// here super keyword are used to just call the parent class constructor;
		
		
	}
	
	
	public static void main(String[] args) {
		
		Experiment experiment = new Experiment();
	
	}
	
}
