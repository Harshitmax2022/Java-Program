package question4;

public class Bank {

	String	branchName;
 String	IfscCode;
 
 
 
 
 
 
   void displayDetails(){
	 System.out.println("Bank Name :"+this.branchName);
	 System.out.println("IFSCcode:"+this.IfscCode);
 }
	
	
}
