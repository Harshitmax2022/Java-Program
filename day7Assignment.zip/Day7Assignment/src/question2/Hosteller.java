package question2;

public class Hosteller  extends Student{

       double	hostelFee;

       
		public double getHostelFee() {
		return hostelFee;
	}


	public void setHostelFee(double hostelFee) {
		this.hostelFee = hostelFee;
	}


		public Hosteller(double hostelfee) {
		  this.hostelFee=hostelfee;
		}
	  
               
	
}
